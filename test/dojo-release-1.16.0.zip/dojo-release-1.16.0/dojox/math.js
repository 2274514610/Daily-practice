//>>built
define("dojox/math",["dojo","dojox","dojox/math/_base"],function(_1,_2,_3){
_1.getObject("math",true,_2);
return _2.math;
});
