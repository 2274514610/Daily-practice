//>>built
define("dojox/lang/functional",["./functional/lambda","./functional/array","./functional/object"],function(df){
return df;
});
