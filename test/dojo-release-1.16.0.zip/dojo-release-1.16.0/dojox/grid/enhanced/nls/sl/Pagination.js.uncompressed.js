define(
"dojox/grid/enhanced/nls/sl/Pagination", ({
	"descTemplate": "${2} - ${3} od ${1} ${0}",
	"firstTip": "Prva stran",
	"lastTip": "Zadnja stran",
	"nextTip": "Naslednja stran",
	"prevTip": "Prejšnja stran",
	"itemTitle": "postavke",
	"singularItemTitle": "postavka",
	"pageStepLabelTemplate": "Stran ${0}",
	"pageSizeLabelTemplate": "${0} postavk na stran",
	"allItemsLabelTemplate": "Vse postavke",
	"gotoButtonTitle": "Pojdi na specifično stran",
	"dialogTitle": "Pojdi na stran",
	"dialogIndication": "Podaj številko strani",
	"pageCountIndication": " (${0} strani)",
	"dialogConfirm": "Pojdi",
	"dialogCancel": "Prekliči",
	"all": "Vse"
})
);
