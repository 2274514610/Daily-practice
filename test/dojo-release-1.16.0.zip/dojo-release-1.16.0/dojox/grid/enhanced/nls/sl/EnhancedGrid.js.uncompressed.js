define(
"dojox/grid/enhanced/nls/sl/EnhancedGrid", ({
	singleSort: "Enostavno razvrščanje",
	nestedSort: "Ugnezdeno razvrščanje",
	ascending: "Kliknite za naraščajoče razvrščanje",
	descending: "Kliknite za padajoče razvrščanje",
	sortingState: "${0} - ${1}",
	unsorted: "Ne razvrščaj tega stolpca",
	indirectSelectionRadio: "Vrstica ${0}, enojni izbor, okence z izbirnim gumbom",
	indirectSelectionCheckBox: "Vrstica ${0}, večkratni izbor, okence s potrditvenimi polji",
	selectAll: "Izberi vse"
})
);
