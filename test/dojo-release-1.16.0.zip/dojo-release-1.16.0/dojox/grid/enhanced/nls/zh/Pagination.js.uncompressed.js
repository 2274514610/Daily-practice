define(
"dojox/grid/enhanced/nls/zh/Pagination", ({
	"descTemplate": "第 ${2} - ${3} 个（共 ${1} ${0}）",
	"firstTip": "首页",
	"lastTip": "末页",
	"nextTip": "下一页",
	"prevTip": "上一页",
	"itemTitle": "项目数",
	"singularItemTitle": "项",
	"pageStepLabelTemplate": "第 ${0} 页",
	"pageSizeLabelTemplate": "每页的 ${0} 项",
	"allItemsLabelTemplate": "所有项",
	"gotoButtonTitle": "转至特定页",
	"dialogTitle": "转至页",
	"dialogIndication": "指定页数",
	"pageCountIndication": "（共 ${0} 页）",
	"dialogConfirm": "运行",
	"dialogCancel": "取消",
	"all": "全部"
})
);
